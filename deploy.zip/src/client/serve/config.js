// Game server configuration
// This will be replaced by the build script with the actual server URL
window.GAME_SERVER_URL = "GAME_SERVER_URL_PLACEHOLDER"; 