export class cargo {
    constructor(mapwidth, mapheight) {
        this.cargo = 5
        this.radius = 10
        this.x = Math.random() * mapwidth
        this.y = Math.random() * mapheight
    }

}